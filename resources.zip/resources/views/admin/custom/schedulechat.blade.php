@include('admin.custom.partials.head')
@include('admin.custom.partials.sidemenu')
<div class="mainwrapper">
<div class="container-fluid">
<div class="calendly-inline-widget" data-url="https://calendly.com/theappkit/buildanapp" style="min-width:320px;height:630px;"></div>
</div>
</div>


<!-- Calendly inline widget begin -->

<script type="text/javascript" src="https://assets.calendly.com/assets/external/widget.js"></script>
<!-- Calendly inline widget end -->
@include('admin.custom.partials.footer')
