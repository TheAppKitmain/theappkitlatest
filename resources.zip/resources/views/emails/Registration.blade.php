Hey {{$user->name}},

<p>Firstly, a big thank you for signing up to We Go Delivery! We are delighted to have you as a member of our community.</p>
<p>Our aim is to keep our customers connected & supplied with their daily essentials & so much more in times of need, or leisure.</p>
<p>We have a wide variety of everyday items that we deliver to your door, at the touch of a button, by one of our friendly team.</p>
<p>Once again, thank you for joining us and we hope to deliver to you soon!</p>
<p>We Go Delivery.</p>
<p>“WeGO so you don't have to”</p>

Thanks,<br>
{{ config('app.name') }}
