<h1>Hey {{ $dataList['customer_name'] }}</h1>

<p> Congratulation on completing {{ $dataList['theme_name'] }} everything looks great. Our team are now busy at work putting the final touches together</p>
<p> It’ll take 72 hours for your app to be uploaded to the respective app stores, this does not account for any review time undertaken by Apple or Google Play stores.</p>
<p> In order for us to upload your app, we will need your Apple & Google Play developer details. If you haven’t done so already please add them to your App Kit account <a href="https://theappkit.co.uk/app/appstore">here</a>. Please note without these details your App will be delayed from going live.</p>
<p> We can’t wait to see your success with your new mobile app.</p>

<br>Many Thanks<br>
<h1> The App Kit </h1>