Hi

Your OTP is {{$otp->code}} and valid for only 5 mintues.

Thanks,<br>


