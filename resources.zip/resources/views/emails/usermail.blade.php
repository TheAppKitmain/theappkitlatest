<p><b>Your Email id :</b>{{$dataList['email']}}</p>
<p></b>Your password : </b>{{$dataList['password']}}</p>